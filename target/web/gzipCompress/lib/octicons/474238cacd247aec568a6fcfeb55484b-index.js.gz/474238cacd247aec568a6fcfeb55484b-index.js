module.exports = {
  keywords: require('./lib/keywords'),
  codepoints: require('./lib/font/codepoints')
}
